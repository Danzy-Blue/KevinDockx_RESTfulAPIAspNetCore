# Building a RESTful API with ASP.NET Core
Starter files for my Building a RESTful API with ASP.NET Core course at Pluralsight: https://app.pluralsight.com/library/courses/asp-dot-net-core-restful-api-building
